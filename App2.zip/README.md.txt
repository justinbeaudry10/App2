App 2 - Justin Beaudry [251107015]

This app is a Combat-Based, sidescrolling 2D Adventure game.

From the main menu, a player must enter their name (exactly 3 characters) before they start the game.
They can access the leaderboard which shows every player's name and time in ascending order.

The player is a humanoid dragon character with 2 attacks, E shoots a fireball that lasts 3 seconds,
while F is a melee horn attack. Both these attacks will kill any enemy immideately.

There are multiple spike pits that will kill the player, as will falling to the bottom of the map
in areas where there is no ground.

There are 2 types of enemies, who both patrol a pre-determined area. If the player touches either of them, they die.

First is the skeleton, who will swipe at the player with its sword if they get too close while the skeleton is 
looking in their direction. If the player is within the attack range when the sword swipes, they die.

Second is the flying eye, who will dive straight down towards the player when they pass underneath.
Of course, if the player gets hit by this, they die.

The level timer runs until the player dies or finishes the level. Upon death, the timer restarts.
The level timer will of course pause if the pause menu is brought up (Esc key), and resume once the 
menu is exited (Esc key again).

Once the player reaches the end of the level (a tree stump), the timer will be stopped and
a winning message will be displayed and take the player back to the main menu after 2 seconds,
at which point their score will be added to the leaderboard.

